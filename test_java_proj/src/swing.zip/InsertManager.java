package swing;
import java.util.*;

class InsertManager
{
	private static Scanner sc=new Scanner(System.in);
	
	public void insert(int type)
	{
		int input=0;
		
		//id입력
		while(true)
		{
			System.out.println(">> 추가하고자 하는 id를 입력하세요!\n");
			try
			{
				System.out.print(">> ");
				input=sc.nextInt();
				System.out.println();
				//id 중복
				if(UserManager.users.containsKey(input))
				{
					System.out.println("이미 존재하는 id입니다. 다른 id를 넣으세요!\n");
				}
				//통과~
				else if(input>0)
				{
					break;
				}
				//이하 그 외 예외처리
				else
				{
					UserManager.disable();
				}
			}
			catch(Exception e)
			{
				UserManager.disable();
			}
		}
		
		
		switch(type)
		{
			case 1:
				//student
				insertStudent(input);
				break;
			case 2:
				//professor
				insertProfessor(input);
				break;
			case 3:
				//staff
				insertStaff(input);
				break;
			default:
				UserManager.disable();
		}
	}
	
	public void insertStudent(int id)
	{
		Student user=new Student();
		
		System.out.println(">> [ Student ] 레코드 추가를 시작합니다.\n");
		
		System.out.print(">> name: ");
		String name=sc.next();
		System.out.print(">> age: ");
		int age=sc.nextInt();
		sc.nextLine();
		System.out.print(">> address: ");
		String address=sc.nextLine();
		System.out.print(">> grade: ");
		int grade=sc.nextInt();
		System.out.print(">> studentIdNo: ");
		int studentIdNo=sc.nextInt();
		System.out.print(">> major: ");
		String major=sc.next();
		
		user=new Student(name, age, address, grade, studentIdNo, major);
		UserManager.addUser(id, user);
		System.out.println();
		System.out.println(">> 레코드가 성공적으로 추가되었습니다.\n");
		UserManager.start();
	}
	
	public void insertProfessor(int id)
	{
		Professor user=new Professor();
		
		System.out.println(">> [ Professor ] 레코드 추가를 시작합니다.\n");
		
		System.out.print(">> name: ");
		String name=sc.next();
		System.out.print(">> age: ");
		int age=sc.nextInt();
		sc.nextLine();
		System.out.print(">> address: ");
		String address=sc.nextLine();
		System.out.print(">> salary: ");
		int salary=sc.nextInt();
		System.out.print(">> position: ");
		String position=sc.next();
		System.out.print(">> major: ");
		String major=sc.next();
		System.out.print(">> course: ");
		String course=sc.next();
		
		user=new Professor(name, age, address, salary, position, null, major, course);
		UserManager.addUser(id, user);
		System.out.println();
		System.out.println(">> 레코드가 성공적으로 추가되었습니다.\n");
		UserManager.start();
	}
	
	public void insertStaff(int id)
	{
		Staff user=new Staff();
		
		System.out.println(">> [ Staff ] 레코드 추가를 시작합니다.\n");
		
		System.out.print(">> name: ");
		String name=sc.next();
		System.out.print(">> age: ");
		int age=sc.nextInt();
		sc.nextLine();
		System.out.print(">> address: ");
		String address=sc.nextLine();
		System.out.print(">> salary: ");
		int salary=sc.nextInt();
		System.out.print(">> position: ");
		String position=sc.next();
		System.out.print(">> department: ");
		String department=sc.next();
		
		user=new Staff(name, age, address, salary, position, null, department);
		UserManager.addUser(id, user);
		System.out.println();
		System.out.println(">> 레코드가 성공적으로 추가되었습니다.\n");
		UserManager.start();
	}
}
